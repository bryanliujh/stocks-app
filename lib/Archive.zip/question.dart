import 'package:flutter/material.dart';

// final vs const => final value know at runtime (e.g. date.now) , const value known at compile time
class Question extends StatelessWidget {
  final String questionText;
  // data from question constructor change (input data) so widget will rebuild
  Question(this.questionText);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.all(10),
      child: Text(
        questionText,
        style: TextStyle(fontSize: 28),
        textAlign: TextAlign.center,
      ),
    );
  }
}
