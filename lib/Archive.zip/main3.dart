import 'package:flutter/material.dart';
import './question.dart';
import './answer.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  MyAppState createState() => MyAppState();
}

// need to seperate state and widget because in flutter state is persistent, only the widget will get re-rendered
class MyAppState extends State<MyApp> {
  var qindex = 0;

  // private _ makes it such that this method cannot be access  outside by another file
  void _answerQuestion() {
    // calls the build method of widget (will not rebuild entire widget tree as it intelligently know which widget to rebuild)
    setState(() {
      qindex = qindex + 1;
    });
    print('answer chosen');
  }

  // decorator is optional but makes it clearer that this build method overrides the one in stateless widget (by default override)
  @override
  Widget build(BuildContext context) {
    var questions = ['hi qustion1', 'q2', 'q3'];
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('my firs app'),
        ),
        body: Column(children: [
          Question(questions[qindex]),
          Answer(_answerQuestion),
        ]),
      ),
    );
  }
}
